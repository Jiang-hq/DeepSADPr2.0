pSADPr peptides dataset: 
1. raw sequence: Dataset without CD-HIT clustering and de-redundancy.
2. preprocessed sequence_model: Perform CD-HIT clustering and de-redundant datasets. 